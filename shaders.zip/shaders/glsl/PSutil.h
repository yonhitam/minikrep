#ifndef PS_UTIL_INCLUDED
#define PS_UTIL_INCLUDED

#define LEAVES_WAVES

#define WATER_WAVES
#define PS_WATER vec2(1.0,0.5)

#define PS_LIGHT vec3(0.700,0.500,0.300)

#define PS_SHADOW vec3(0.0,0.0,0.0)
float blur = 0.005;
#define PS_FLAT_SHADING
#define PS_SUN_LIGHT 0.5
#define DUSK 0.25
float dusk1 = 0.25;
float dusk2 = 0.25;
#define PS_TONEMAP
#define TM_SATURATION 1.10
#define TM_EXPOSURE 1.0
#define TM_BRIGHTNESS 1.0
#define TM_GAMMA 1.0
#define TM_CONTRAST 1.0

#endif
